window.EVENT_CONFIG = {
  eventName: 'Lista Evento',
  apiUrl: 'INCOLLA_QUI_URL_WEB_APP_GOOGLE_APPS_SCRIPT'
};

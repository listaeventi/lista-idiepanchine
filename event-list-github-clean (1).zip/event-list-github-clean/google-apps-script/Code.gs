const SHEET_NAME = 'Iscrizioni';

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) sheet.appendRow(['Data', 'Nome', 'Cognome']);
  return sheet;
}

function doPost(e) {
  const data = JSON.parse(e.postData.contents || '{}');
  const firstName = String(data.firstName || '').trim().slice(0, 80);
  const lastName = String(data.lastName || '').trim().slice(0, 80);
  if (data.website || firstName.length < 2 || lastName.length < 2) return ContentService.createTextOutput('invalid');
  getSheet_().appendRow([new Date(), firstName, lastName]);
  return ContentService.createTextOutput('ok');
}

function doGet(e) {
  const p = e.parameter || {};
  if (p.action === 'count') {
    const count = Math.max(0, getSheet_().getLastRow() - 1);
    const body = JSON.stringify({count});
    if (p.callback) return ContentService.createTextOutput(`${p.callback}(${body});`).setMimeType(ContentService.MimeType.JAVASCRIPT);
    return ContentService.createTextOutput(body).setMimeType(ContentService.MimeType.JSON);
  }
  return ContentService.createTextOutput('ok');
}

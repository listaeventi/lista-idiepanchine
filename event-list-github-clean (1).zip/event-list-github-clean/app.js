(() => {
  'use strict';
  const cfg = window.EVENT_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const configured = () => cfg.apiUrl && !cfg.apiUrl.includes('INCOLLA_QUI');

  $('eventName').textContent = cfg.eventName || 'Lista Evento';
  document.title = `${cfg.eventName || 'Lista Evento'} — Lista`;

  const cookieKey = 'lista_evento_cookie_ok';
  if (!localStorage.getItem(cookieKey)) $('cookieBanner').hidden = false;
  $('cookieOk').addEventListener('click', () => {
    localStorage.setItem(cookieKey, '1');
    $('cookieBanner').hidden = true;
  });

  const clean = (v) => String(v || '').trim().replace(/\s+/g, ' ').slice(0, 80);

  function loadCount() {
    if (!configured()) return;
    const callback = `count_${Date.now()}`;
    const script = document.createElement('script');
    const cleanup = () => { delete window[callback]; script.remove(); };
    window[callback] = (data) => {
      $('count').textContent = new Intl.NumberFormat('it-IT').format(Number(data?.count || 0));
      cleanup();
    };
    script.onerror = cleanup;
    script.src = `${cfg.apiUrl}?action=count&callback=${encodeURIComponent(callback)}`;
    document.head.appendChild(script);
    setTimeout(cleanup, 8000);
  }

  $('registrationForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const firstName = clean(form.firstName.value);
    const lastName = clean(form.lastName.value);
    const message = $('formMessage');
    const button = $('submitButton');
    message.textContent = '';

    if (!configured()) {
      message.textContent = 'Il collegamento alla lista non è ancora configurato.';
      return;
    }
    if (firstName.length < 2 || lastName.length < 2) {
      message.textContent = 'Inserisci nome e cognome.';
      return;
    }
    if (clean(form.website.value)) {
      message.textContent = 'Iscrizione non valida.';
      return;
    }

    button.disabled = true;
    button.textContent = 'ISCRIZIONE…';
    try {
      await fetch(cfg.apiUrl, {
        method: 'POST',
        mode: 'no-cors',
        headers: {'Content-Type': 'text/plain;charset=utf-8'},
        body: JSON.stringify({firstName, lastName, website: '', submittedAt: new Date().toISOString()})
      });
      form.reset();
      $('success').hidden = false;
      setTimeout(() => $('success').hidden = true, 3500);
      setTimeout(loadCount, 1200);
    } catch {
      message.textContent = 'Non è stato possibile inviare l’iscrizione. Riprova.';
    } finally {
      button.disabled = false;
      button.textContent = 'ENTRA IN LISTA';
    }
  });

  loadCount();
})();

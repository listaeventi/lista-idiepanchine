# LISTA EVENTO — GitHub Pages

Versione statica del sito. Pubblicabile su GitHub Pages.

## File da caricare su GitHub
Carica il contenuto di questa cartella direttamente nella root del repository:

- index.html
- app.js
- config.js
- styles.css
- privacy.html
- cookie.html
- google-apps-script/Code.gs
- .nojekyll

## Primo utilizzo
1. Crea un Google Sheet.
2. Estensioni → Apps Script.
3. Incolla `google-apps-script/Code.gs`.
4. Distribuisci come Applicazione web.
5. Copia l'URL e inseriscilo in `config.js` al posto di `INCOLLA_QUI_URL_WEB_APP_GOOGLE_APPS_SCRIPT`.
6. In `config.js` cambia `Lista Evento` con il nome dell'evento.
7. Pubblica con GitHub Pages.

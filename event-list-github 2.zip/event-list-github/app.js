const cfg = window.EVENT_CONFIG || { eventName: 'Nome Evento', apiUrl: '' };
const $ = (id) => document.getElementById(id);

function cleanText(value, max = 80) {
  return String(value || '').trim().replace(/\s+/g, ' ').slice(0, max);
}

function getCookie(name) {
  return document.cookie.split('; ').find(v => v.startsWith(name + '='))?.split('=')[1] || null;
}

function setCookie(name, value, days = 180) {
  const expires = new Date(Date.now() + days * 864e5).toUTCString();
  document.cookie = `${name}=${value}; Expires=${expires}; Path=/; SameSite=Lax; Secure`;
}

function initPage() {
  $('eventName').textContent = cfg.eventName || 'Nome Evento';
  document.title = `${cfg.eventName || 'Nome Evento'} — Lista`;
}

function showCookieBanner() {
  $('cookieBanner').hidden = false;
}

function saveCookieChoice() {
  setCookie('cookie_preferences', 'necessary');
  $('cookieBanner').hidden = true;
}

function initCookies() {
  if (!getCookie('cookie_preferences')) showCookieBanner();
  $('acceptNecessary').addEventListener('click', saveCookieChoice);
  $('cookieSettings').addEventListener('click', showCookieBanner);
}

function isConfigured() {
  return cfg.apiUrl && !cfg.apiUrl.includes('INCOLLA_QUI');
}

function loadCount() {
  if (!isConfigured()) {
    $('count').textContent = '—';
    return;
  }

  const callback = `eventListCount_${Date.now()}`;
  window[callback] = (data) => {
    $('count').textContent = new Intl.NumberFormat('it-IT').format(Number(data?.count || 0));
    cleanup();
  };

  const script = document.createElement('script');
  const cleanup = () => {
    delete window[callback];
    script.remove();
  };
  script.onerror = cleanup;
  script.src = `${cfg.apiUrl}?action=count&callback=${encodeURIComponent(callback)}`;
  document.head.appendChild(script);
  setTimeout(cleanup, 8000);
}

async function sendRegistration(payload) {
  // Apps Script Web Apps can receive this cross-origin POST without a preflight
  // when sent as text/plain. The response is intentionally opaque (no-cors).
  await fetch(cfg.apiUrl, {
    method: 'POST',
    mode: 'no-cors',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(payload),
    keepalive: true
  });
}

$('registrationForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = $('submitButton');
  const message = $('formMessage');
  message.textContent = '';

  if (!isConfigured()) {
    message.textContent = 'Configura prima l’URL del modulo nel file config.js.';
    return;
  }

  const firstName = cleanText(form.firstName.value);
  const lastName = cleanText(form.lastName.value);
  const website = cleanText(form.website.value);

  if (firstName.length < 2 || lastName.length < 2) {
    message.textContent = 'Controlla nome e cognome.';
    return;
  }

  if (website) {
    message.textContent = 'Iscrizione non valida.';
    return;
  }

  button.disabled = true;
  button.textContent = 'ISCRIZIONE…';

  try {
    await sendRegistration({
      firstName,
      lastName,
      website: '',
      submittedAt: new Date().toISOString()
    });

    form.reset();
    message.textContent = '';
    $('successToast').hidden = false;
    setTimeout(() => { $('successToast').hidden = true; }, 3500);
    setTimeout(loadCount, 1000);
  } catch {
    message.textContent = 'Non è stato possibile inviare l’iscrizione. Riprova.';
  } finally {
    button.disabled = false;
    button.textContent = 'ENTRA IN LISTA';
  }
});

initPage();
initCookies();
loadCount();

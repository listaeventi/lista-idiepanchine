window.EVENT_CONFIG = {
  eventName: 'Inidiepanchine',
  apiUrl: 'https://docs.google.com/spreadsheets/d/e/2PACX-1vTa5vemioV4Cg0sVIquQ2xuMnKjOVx9MZoNeDmMyQVdj3hIKC7IQ3XxpZSsGJY-ovikQeeUrB0CH1d1/pubhtml'
};

# Event List — versione GitHub Pages

Questa versione non usa Node.js, PHP o un server da mantenere.

- Frontend statico: GitHub Pages
- Database: Google Sheet
- Backend minimo: Google Apps Script Web App
- Admin: il Google Sheet stesso
- Nessun analytics o advertising attivo di default

## 1. Crea il Google Sheet

Crea un nuovo Google Sheet, ad esempio `Lista Evento`.

## 2. Crea il backend Apps Script

Nel Google Sheet apri **Estensioni → Apps Script**.

Elimina l'eventuale codice presente e incolla tutto il file `google-apps-script/Code.gs`.

Salva.

## 3. Pubblica Apps Script come Web App

In Apps Script scegli **Deploy / Distribuisci → New deployment / Nuova implementazione**.

Come tipo scegli **Web app / Applicazione web**.

Imposta l'esecuzione come proprietario del progetto e consenti l'accesso anche agli utenti anonimi, in modo che il modulo pubblico possa inviare le iscrizioni.

Completa il deploy e copia l'URL della Web App.

## 4. Collega il sito al backend

Apri `config.js` e sostituisci:

`INCOLLA_QUI_URL_WEB_APP_GOOGLE_APPS_SCRIPT`

con l'URL copiato da Apps Script.

Puoi anche cambiare:

`Nome Evento`

con il nome vero dell'evento.

## 5. Carica su GitHub

Crea un nuovo repository GitHub e carica **i file presenti nella cartella di questo progetto**, non la cartella contenitore.

La struttura minima deve essere:

- `index.html`
- `app.js`
- `config.js`
- `styles.css`
- `privacy.html`
- `cookie.html`
- `.nojekyll`

La cartella `google-apps-script` serve come copia del backend e non viene eseguita da GitHub Pages.

## 6. Attiva GitHub Pages

Nel repository vai in **Settings → Pages**.

Scegli la pubblicazione dalla branch principale e dalla cartella root `/`.

GitHub Pages pubblicherà il sito con un indirizzo del tipo `https://TUO-USERNAME.github.io/NOME-REPOSITORY/`.

## 7. Completa privacy e cookie

Prima di pubblicare sostituisci i campi tra parentesi quadre in `privacy.html` e `cookie.html` con i dati reali dell'organizzatore, il periodo di conservazione e le informazioni pertinenti sui fornitori realmente utilizzati.

I testi forniti sono una base tecnica e non sostituiscono una verifica legale del caso concreto.

## Come funziona

Quando un utente invia il modulo, il browser invia i dati al Web App di Google Apps Script. Lo script aggiunge una riga al foglio `Iscrizioni`.

Il contatore della home legge esclusivamente il numero di righe presenti nel foglio e non espone i nomi pubblicamente.

Per comodità, la prima esecuzione di Apps Script crea automaticamente il foglio `Iscrizioni` con le colonne:

`Data | Nome | Cognome | Honeypot`

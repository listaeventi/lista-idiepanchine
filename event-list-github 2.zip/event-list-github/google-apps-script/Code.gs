/**
 * Google Apps Script backend for the GitHub Pages event list.
 *
 * 1) Create a Google Sheet.
 * 2) Open Extensions > Apps Script.
 * 3) Paste this entire file.
 * 4) Save and deploy as a Web app.
 *
 * The first run creates a sheet named "Iscrizioni" with these columns:
 * Data | Nome | Cognome | Honeypot
 */

const SHEET_NAME = 'Iscrizioni';
const HEADERS = ['Data', 'Nome', 'Cognome', 'Honeypot'];

function getSheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = spreadsheet.insertSheet(SHEET_NAME);

  if (sheet.getLastRow() === 0) {
    sheet.appendRow(HEADERS);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function json_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

function jsonp_(callback, data) {
  const safeCallback = /^[A-Za-z_$][0-9A-Za-z_$\.]*$/.test(callback || '') ? callback : null;
  if (!safeCallback) return json_(data);
  return ContentService
    .createTextOutput(`${safeCallback}(${JSON.stringify(data)})`)
    .setMimeType(ContentService.MimeType.JAVASCRIPT);
}

function doGet(e) {
  const action = String(e?.parameter?.action || 'health');

  if (action === 'count') {
    const sheet = getSheet_();
    const count = Math.max(0, sheet.getLastRow() - 1);
    return jsonp_(e?.parameter?.callback, { ok: true, count });
  }

  return json_({ ok: true, service: 'event-list' });
}

function doPost(e) {
  try {
    const raw = e?.postData?.contents || '{}';
    const data = JSON.parse(raw);

    const firstName = sanitize_(data.firstName);
    const lastName = sanitize_(data.lastName);
    const website = sanitize_(data.website);
    // Basic validation.
    if (website) return json_({ ok: false, error: 'spam' });
    if (firstName.length < 2 || lastName.length < 2) {
      return json_({ ok: false, error: 'invalid_name' });
    }

    const lock = LockService.getScriptLock();
    lock.waitLock(5000);
    try {
      const sheet = getSheet_();
      sheet.appendRow([
        new Date(),
        firstName,
        lastName,
        ''
      ]);
    } finally {
      lock.releaseLock();
    }

    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: 'server_error' });
  }
}

function sanitize_(value) {
  return String(value ?? '')
    .replace(/[<>]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80);
}
